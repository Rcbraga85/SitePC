document.addEventListener('DOMContentLoaded', function() {
    // Elementos do DOM
    const startBtn = document.getElementById('start-btn');
    const configurator = document.getElementById('configurator');
    const steps = document.querySelectorAll('.step');
    const nextBtns = document.querySelectorAll('.btn-next');
    const prevBtns = document.querySelectorAll('.btn-prev');
    const submitBtn = document.querySelector('.btn-submit');
    const resultModal = document.getElementById('result-modal');
    const closeModal = document.querySelector('.close-modal');
    const budgetOptions = document.querySelectorAll('.budget-option');
    const paymentOptions = document.querySelectorAll('.payment-option');
    const selectAllBrandsBtn = document.querySelector('.select-all-brands');
    const brandOptions = document.querySelectorAll('.brand-option input');
    
    // Dados do formulário
    let formData = {
        budget: '',
        brands: [],
        paymentMethod: ''
    };
    
    // Iniciar o configurador
    startBtn.addEventListener('click', function() {
        // Mostrar o configurador
        configurator.style.display = 'block';
        // Esconder a seção hero
        document.querySelector('.hero-image').style.display = 'none';
        // Rolar para o configurador
        configurator.scrollIntoView({ behavior: 'smooth' });
    });
    
    // Navegação entre etapas
    nextBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            const currentStep = this.closest('.step');
            const currentStepIndex = Array.from(steps).indexOf(currentStep);
            
            // Validar a etapa atual antes de avançar
            if (validateStep(currentStepIndex)) {
                currentStep.classList.remove('active');
                steps[currentStepIndex + 1].classList.add('active');
            }
        });
    });
    
    prevBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            const currentStep = this.closest('.step');
            const currentStepIndex = Array.from(steps).indexOf(currentStep);
            
            currentStep.classList.remove('active');
            steps[currentStepIndex - 1].classList.add('active');
        });
    });
    
    // Seleção de orçamento
    budgetOptions.forEach(option => {
        option.addEventListener('click', function() {
            budgetOptions.forEach(opt => opt.classList.remove('selected'));
            this.classList.add('selected');
            formData.budget = this.textContent.trim();
        });
    });
    
    // Seleção de marcas
    brandOptions.forEach(option => {
        option.addEventListener('change', function() {
            updateBrandSelection();
        });
    });
    
    // Selecionar todas as marcas
    selectAllBrandsBtn.addEventListener('click', function() {
        const allChecked = Array.from(brandOptions).every(opt => opt.checked);
        
        brandOptions.forEach(option => {
            option.checked = !allChecked;
        });
        
        updateBrandSelection();
    });
    
    // Seleção de método de pagamento
    paymentOptions.forEach(option => {
        option.addEventListener('click', function() {
            paymentOptions.forEach(opt => opt.classList.remove('selected'));
            this.classList.add('selected');
            formData.paymentMethod = this.textContent.trim();
        });
    });
    
    // Enviar formulário
    submitBtn.addEventListener('click', function() {
        if (validateStep(2)) {
            searchBestSetup();
        }
    });
    
    // Fechar modal
    closeModal.addEventListener('click', function() {
        resultModal.style.display = 'none';
    });
    
    // Fechar modal ao clicar fora
    window.addEventListener('click', function(event) {
        if (event.target === resultModal) {
            resultModal.style.display = 'none';
        }
    });
    
    // Funções auxiliares
    function validateStep(stepIndex) {
        switch (stepIndex) {
            case 0: // Orçamento
                if (!formData.budget) {
                    alert('Por favor, selecione um orçamento.');
                    return false;
                }
                return true;
            
            case 1: // Marcas
                updateBrandSelection();
                return true;
            
            case 2: // Método de pagamento
                if (!formData.paymentMethod) {
                    alert('Por favor, selecione um método de pagamento.');
                    return false;
                }
                return true;
            
            default:
                return true;
        }
    }
    
    function updateBrandSelection() {
        formData.brands = Array.from(brandOptions)
            .filter(opt => opt.checked)
            .map(opt => opt.value);
    }
    
    async function searchBestSetup() {
        // Simulação de busca (em um cenário real, isso seria uma chamada de API)
        showLoadingState();
        
        try {
            // Em um cenário real, faríamos uma chamada à API
            // const response = await searchComponents('pc gaming', 'all', formData.budget);
            // if (response.success) {
            //     displayResult(response.data);
            // }
            
            // Simulando um tempo de processamento
            setTimeout(() => {
                const mockResult = generateMockResult();
                displayResult(mockResult);
            }, 2000);
        } catch (error) {
            console.error('Erro ao buscar setup:', error);
            alert('Ocorreu um erro ao buscar o melhor setup. Tente novamente.');
            submitBtn.textContent = 'Buscar Melhor Setup';
            submitBtn.disabled = false;
        }
    }
    
    // Função para buscar componentes
    async function searchComponents(query, category, maxPrice) {
      try {
        let url = `http://localhost:3001/api/search?q=${encodeURIComponent(query)}`;
        if (category) url += `&category=${encodeURIComponent(category)}`;
        if (maxPrice) url += `&maxPrice=${encodeURIComponent(maxPrice)}`;
        
        const response = await fetch(url);
        if (!response.ok) throw new Error('Erro ao buscar componentes');
        
        return await response.json();
      } catch (error) {
        console.error('Erro na busca:', error);
        return { success: false, components: [] };
      }
    }
    
    function showLoadingState() {
        // Mostrar estado de carregamento
        submitBtn.textContent = 'Buscando...';
        submitBtn.disabled = true;
    }
    
    function displayResult(result) {
        // Resetar botão de envio
        submitBtn.textContent = 'Buscar Melhor Setup';
        submitBtn.disabled = false;
        
        // Preencher o modal com os resultados
        const resultContainer = document.querySelector('.pc-config-result');
        resultContainer.innerHTML = '';
        
        // Adicionar cada componente ao resultado
        result.components.forEach(component => {
            const componentEl = document.createElement('div');
            componentEl.className = 'component-item';
            componentEl.innerHTML = `
                <div class="component-info">
                    <div class="component-name">${component.type}</div>
                    <div class="component-model">${component.name}</div>
                </div>
                <div class="component-price">R$ ${component.price.toFixed(2)}</div>
                <a href="${component.link}" class="component-link" target="_blank">Ver na loja</a>
            `;
            resultContainer.appendChild(componentEl);
        });
        
        // Atualizar preços totais
        document.querySelector('.price-cash').querySelector('.price').textContent = 
            `R$ ${result.totalPrice.cash.toFixed(2)}`;
        document.querySelector('.price-installment').querySelector('.price').textContent = 
            `R$ ${result.totalPrice.installment.toFixed(2)}`;
        
        // Mostrar o modal
        resultModal.style.display = 'block';
    }
    
    function generateMockResult() {
        // Gerar um resultado simulado com base no orçamento selecionado
        const budget = parseInt(formData.budget.replace(/[^0-9]/g, ''));
        const midBudget = budget / 2;
        
        // Ajustar preços com base no orçamento
        const gpuPrice = midBudget * 0.4;
        const cpuPrice = midBudget * 0.25;
        const moboPrice = midBudget * 0.15;
        const ramPrice = midBudget * 0.1;
        const ssdPrice = midBudget * 0.1;
        const psuPrice = midBudget * 0.1;
        const casePrice = midBudget * 0.15;
        const coolerPrice = midBudget * 0.1;
        
        // Calcular preço total
        const totalCash = gpuPrice + cpuPrice + moboPrice + ramPrice + ssdPrice + psuPrice + casePrice + coolerPrice;
        const totalInstallment = totalCash * 1.12; // 12% de acréscimo para pagamento parcelado
        
        return {
            components: [
                {
                    type: 'Processador',
                    name: 'AMD Ryzen 7 5800X 3.8GHz',
                    price: cpuPrice,
                    link: 'https://www.terabyteshop.com.br'
                },
                {
                    type: 'Placa de Vídeo',
                    name: 'NVIDIA GeForce RTX 3070 8GB',
                    price: gpuPrice,
                    link: 'https://www.terabyteshop.com.br'
                },
                {
                    type: 'Placa-mãe',
                    name: 'ASUS ROG Strix B550-F Gaming',
                    price: moboPrice,
                    link: 'https://www.terabyteshop.com.br'
                },
                {
                    type: 'Memória RAM',
                    name: 'Corsair Vengeance RGB Pro 16GB (2x8GB) 3200MHz',
                    price: ramPrice,
                    link: 'https://www.terabyteshop.com.br'
                },
                {
                    type: 'Armazenamento',
                    name: 'Samsung 970 EVO Plus NVMe M.2 1TB',
                    price: ssdPrice,
                    link: 'https://www.terabyteshop.com.br'
                },
                {
                    type: 'Fonte de Alimentação',
                    name: 'Corsair RM750x 750W 80 Plus Gold',
                    price: psuPrice,
                    link: 'https://www.terabyteshop.com.br'
                },
                {
                    type: 'Gabinete',
                    name: 'NZXT H510 Elite RGB Preto',
                    price: casePrice,
                    link: 'https://www.terabyteshop.com.br'
                },
                {
                    type: 'Cooler',
                    name: 'Cooler Master Hyper 212 RGB',
                    price: coolerPrice,
                    link: 'https://www.terabyteshop.com.br'
                }
            ],
            totalPrice: {
                cash: totalCash,
                installment: totalInstallment
            }
        };
    }
    
    // Botões de ação no resultado
    document.querySelector('.btn-save').addEventListener('click', function() {
        alert('Configuração salva com sucesso!');
    });
    
    document.querySelector('.btn-share').addEventListener('click', function() {
        alert('Link de compartilhamento copiado para a área de transferência!');
    });
    
    document.querySelector('.btn-export').addEventListener('click', function() {
        alert('Exportando configuração para PDF...');
    });
});